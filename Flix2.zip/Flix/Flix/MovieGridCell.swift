//
//  MovieGridCell.swift
//  Flix
//
//  Created by W on 9/20/22.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
}
